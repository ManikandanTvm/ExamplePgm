
import java.io.Serializable;

public class Loop implements Serializable, Comparable<Loop> {
	private static final long serialVersionUID = -3560974605866754008L;

	private Integer id;
	private String name;
	private Integer groupNumber;
	private Integer nbOccurrences;
	private int executionOrder;
	private Integer seqId;

	public Loop(int i, String str, int k, int l, int j, int seqid) {
		// TODO Auto-generated constructor stub
		super();
		this.id = i;
		this.name = str;
		this.groupNumber = k;
		this.executionOrder = j;
		this.seqId = seqid;
	}

	public Loop() {
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getGroupNumber() {
		return groupNumber;
	}

	public void setGroupNumber(Integer groupNumber) {
		this.groupNumber = groupNumber;
	}

	public Integer getNbOccurrences() {
		return nbOccurrences;
	}

	public void setNbOccurrences(Integer nbOccurrences) {
		this.nbOccurrences = nbOccurrences;
	}

	public int getExecutionOrder() {
		return executionOrder;
	}

	public void setExecutionOrder(int executionOrder) {
		this.executionOrder = executionOrder;
	}

	public Integer getSeqId() {
		return seqId;
	}

	public void setSeqId(Integer seqId) {
		this.seqId = seqId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		/*
		 * result = prime * result + executionOrder; result = prime * result +
		 * ((groupNumber == null) ? 0 : groupNumber.hashCode());
		 * 
		 * result = prime * result + ((name == null) ? 0 : name.hashCode());
		 * result = prime * result + ((nbOccurrences == null) ? 0 :
		 * nbOccurrences.hashCode()); result = prime * result + ((seqId == null)
		 * ? 0 : seqId.hashCode());
		 */
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Loop other = (Loop) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		/*
		 * if (executionOrder != other.executionOrder) return false; if
		 * (groupNumber == null) { if (other.groupNumber != null) return false;
		 * } else if (!groupNumber.equals(other.groupNumber)) return false;
		 * 
		 * if (name == null) { if (other.name != null) return false; } else if
		 * (!name.equals(other.name)) return false; if (nbOccurrences == null) {
		 * if (other.nbOccurrences != null) return false; } else if
		 * (!nbOccurrences.equals(other.nbOccurrences)) return false; if (seqId
		 * == null) { if (other.seqId != null) return false; } else if
		 * (!seqId.equals(other.seqId)) return false;
		 */
		return true;
	}

	@Override
	public int compareTo(Loop o) {
		// TODO Auto-generated method stub
		if (this.id == o.id)
			return 1;
		else
			return -1;

	}

	@Override
	public String toString() {
		return "Loop [id=" + id + ", groupNumber=" + groupNumber + "]";
	}

}
