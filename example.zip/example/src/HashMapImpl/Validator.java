package HashMapImpl;

/*import org.junit.Test;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static junit.framework.TestCase.assertNull;*/

public class Validator {
    //@Test
    public static void  main(String[] ar) {
        MyMap<String, String> myMap = new MyMap<>(3);
        myMap.put("USA", "Washington DC");
        myMap.put("Nepal", "Kathmandu");
        myMap.put("India", "New Delhi");
        myMap.put("Australia", "Sydney");
System.out.println("myMap -> "+myMap);
		/*
		 * assertNotNull(myMap); assertEquals(4, myMap.size());
		 * assertEquals("Kathmandu", myMap.get("Nepal")); assertEquals("Sydney",
		 * myMap.get("Australia"));
		 */
    }
}