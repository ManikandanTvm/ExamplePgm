import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author z012297
 *
 */
public class DuplicateRemovalPgm {

	public static void main(String[] args) {
		List<Loop> lp = new ArrayList<Loop>();
		// Creating Books
		Loop b1 = new Loop(101, "Loop1", 1, 1, 1, 1);
		Loop b2 = new Loop(104, "Loop1", 1, 1, 1, 1);
		Loop b3 = new Loop(102, "Loop2", 1, 1, 1, 2);
		Loop b5 = new Loop(103, "Loop2", 1, 1, 1, 2);
		Loop b4 = new Loop(103, "Loop3", 1, 1, 1, 2); // Adding Books to HashSet
		lp.add(b1);
		lp.add(b2);
		lp.add(b3);
		lp.add(b4);
		lp.add(b5);
		Set<Loop> loopSet = new HashSet<Loop>(lp);
		/*
		 * LinkedList<Integer> ls = new LinkedList<>(); ls.add(-8); ls.add(10);
		 * ls.add(-20); Comparator<Integer> r = Collections.reverseOrder();
		 * Collections.sort(ls); for (int i : ls) { System.out.println(i); }
		 */
		// Traversing HashSet
		for (Loop l : loopSet) {
			System.out.println(l.getId() + " " + l.getName() + " " + l.getGroupNumber() + " " + l.getExecutionOrder());
		}
	}

}
