// Java code to illustrate 
// the containsValue() method 

import java.util.*; 

public class Map_Demo { 
	public static void main(String[] args) 
	{ 

		// Creating an empty SortedMap 
		SortedMap<Integer, String> map 
			= new TreeMap<Integer, String>(); 

		// Mapping string values to int keys 
		map.put(10, "Geeks"); 
		map.put(15, "4"); 
		map.put(20, "Geeks"); 
		map.put(25, "Welcomes"); 
		map.put(30, "You"); 

		// Displaying the SortedMap 
		System.out.println( 
			"Initial Mappings are: "
			+ map); 

		// Checking for the Value 'Geeks' 
		System.out.println( 
			"Is the value 'Geeks' present? "
			+ map.get(10)); 

		// Checking for the Value 'World' 
		System.out.println( 
			"Is the value 'World' present? "
			+ map.containsValue("World")); 
	} 
} 
