
public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(10 + 20 + "Welcome");
		System.out.println("Welcome" + 10 + 20);
	}

}
