import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class SecondbiggestNum2 {
	public static void main(String ars[]) {
		int[] ls = { 10, 20, 20, 30, 40, 50, 50 };
		int max = 0, secMax = 0;
		for (int i = 0; i < ls.length; i++) {
			if (ls[i] > max) {
				secMax = max;
				max = ls[i];
			}
		}
		System.out.println("2nd biggest number is : " + secMax);
		for (int i = 0; i < ls.length; i++) {
			if (ls[i] > max) {
				max = ls[i];
			}
			if (ls[i] > secMax && ls[i] < max) {
				secMax = ls[i];
			}
		}

		List<Integer> list = IntStream.of(ls).boxed().collect(Collectors.toList());
		System.out.println(list);

		System.out.println("2nd biggest number is : " + secMax);
		/*
		 * int max = 0, x = 0, secondhighestnum = 0; while (n > 0) { x = n % 10;
		 * if (x > max) { max = x; } if (x > secondhighestnum && x < max) {
		 * secondhighestnum = x; } n = n / 10; }
		 * System.out.println("2nd biggest number is : " + secondhighestnum);
		 */

	}
}
