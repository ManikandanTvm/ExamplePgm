
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BiggestNumFrmString {
	public static void main(String ars[]) {
		String s = "0145a34s232a389";
		String s1 = "Bread$$##12.5$$##10";
		Stream.of(s1.replaceAll("[^ .a-zA-Z0-9]", " ").split(" ")).forEach(System.out::println);
		Predicate<Integer> isDigit = idx -> s.charAt(idx) >= 48 && s.charAt(idx) <= 57;

		Integer max = Stream.of(s.replaceAll("^\\D+", "").split("\\D+")).mapToInt(Integer::parseInt).max().orElse(-1);

		// without java 8
		int num = 0, res = 0;
		// Start traversing the given string
		for (int i = 0; i < s.length(); i++) {
			// If a numeric value comes, start converting
			// it into an integer till there are consecutive
			// numeric digits
			if (s.charAt(i) >= '0' && s.charAt(i) <= '9')
				num = num * 10 + (s.charAt(i) - '0');
			// Update maximum value
			else {
				res = Integer.max(res, num);
				// Reset the number
				num = 0;
			}
		}
		System.out.println(" maximum value  is : " + res);

		// To find the biggest digit
		Optional<Character> biggesNum = Stream.iterate(0, n -> n + 1).limit(s.length()).filter(isDigit)
				.map(idx -> s.charAt(idx)).max(Comparator.naturalOrder());

		System.out.println(biggesNum);

		// To find the biggest digit without java 8
		char[] strTocArray = s.toCharArray();
		char mx = '0';
		for (char c : strTocArray) {
			if (!(c >= 'a' || c >= 'A') && (c <= 'z' || c <= 'Z')) {
				if (c > mx)
					mx = c;
			}
		}
		System.out.println(" maximum value  is : " + mx);

		// comparing 2 attributes in java
		List<Loop> lst = new ArrayList<>();
		Loop l1 = new Loop();
		l1.setId(1);
		l1.setGroupNumber(2);
		Loop l2 = new Loop();
		l2.setId(1);
		l2.setGroupNumber(2);
		lst.add(l1);
		lst.add(l2);
		List<Loop> asdf = lst.stream().sorted(Comparator.comparing(Loop::getId).thenComparing(Loop::getGroupNumber))
				.collect(Collectors.toList());
		System.out.println("Comparing 2 fileds in java : " + asdf);
		System.out.println(Stream.of(1, 2, 1, 2, 3).count());
	}
}
