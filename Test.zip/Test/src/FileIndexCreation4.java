
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FileIndexCreation4 {

	public static void main(String args[]) {

		Path textFilePath = Paths.get("C:/Users/z012297/Downloads\\1342-0.txt");

		try {
			Stream<String> fileLines = Files.lines(textFilePath);

			Map<String, Long> unsortMap = fileLines.flatMap(line -> Arrays.stream(line.trim().split("\\s")))
					.map(word -> word.replaceAll("[^a-zA-Z]", "").toLowerCase().trim())
					.filter(word -> word.length() > 0).map(word -> new SimpleEntry<>(word, 1))
					.collect(Collectors.groupingBy(SimpleEntry::getKey, Collectors.counting()));

			// sort by values, and reserve it, 10,9,8,7,6...
			Map<String, Long> result = unsortMap.entrySet().stream()
					.sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
					.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (oldValue, newValue) -> oldValue,
							LinkedHashMap::new));

			// group by chapter and page
			Map<String, Long> chapterMap = Files.lines(textFilePath)
					.flatMap(line -> Arrays.stream(line.trim().split("\\s")))
					.map(word -> word.replaceAll("[^a-zA-Z]", "").toLowerCase().trim())
					.filter(word -> word.length() > 0).filter(word -> word.contentEquals("Chapter"))
					.map(word -> new SimpleEntry<>(word, 1))

					.collect(Collectors.groupingBy(SimpleEntry::getKey, Collectors.counting()));

			List<String> lines = (List) Files.lines(textFilePath).collect(Collectors.toList());

			result.forEach((k, v) -> System.out.println(String.format("%s ==>> %d", k, v)));

			IntStream.range(0, lines.size()).filter(i -> lines.get(i).contains("attendance"))
					.forEach(System.out::println);

			chapterMap.forEach((k, v) -> System.out.println(String.format("%s =fdf=>> %d", k, v)));

		} catch (IOException ioException) {
			ioException.printStackTrace();
		}
		// System.out.println("Number of words in WordCount.txt: "+ wordCount);
	}
}