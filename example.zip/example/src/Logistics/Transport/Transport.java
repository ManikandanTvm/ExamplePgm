
package Logistics.Transport;

public interface Transport {
    public void load();
    public void drive();
}